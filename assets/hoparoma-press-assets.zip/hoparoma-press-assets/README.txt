Hoparoma · Editorial Press Assets
=================================

Contents:
- icon-1024.png · icon-512.png         App icon (App Store + general use)
- hero-mockup.png                      Hero shot: iPhone 17 Pro Max with Hoparoma home (transparent BG)
- screen-1-home.png                    Home screen
- screen-2-sensory-radar.png           Sensory radar (Bento card)
- screen-3-axis-breakdown.png          Per-axis sensory breakdown
- screen-4-compound-depth.png          Aroma compound µg/L predictions
- Designed-in-Tokyo_BG.png             Hazy IPA brand photograph
- section-2.png                        Brewery / taproom photograph (Tokyo context)
- app-store-badge-black.svg            Apple App Store badge (light theme)
- app-store-badge-white.svg            Apple App Store badge (dark theme)

Brand palette:
- Hop Green       #5e9522
- Hop Green Deep  #3a6700
- Carbon          #1a1a1a
- Vellum          #f9f9f8
- Tech Gray       #8c8c8c
- Hairline        #e5e5e5

Typography:
- Headlines       Inter (600 / 700 weight, -0.02em letter-spacing)
- Body            Hanken Grotesk (400 / 500)
- Technical       JetBrains Mono (400 / 500, +0.06em letter-spacing)

Contact:
hoparoma@tsukayasuzuki.com
Tsukaya Suzuki / Pith Films Tokyo
